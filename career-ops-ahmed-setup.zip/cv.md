# CV -- Ahmed Miah

**Headline:** IT Support | Cyber Security Graduate (First Class BSc)
**Location:** Walsall, West Midlands, UK
**Email:** ahmedmiah1999@outlook.com
**Phone:** 07933 798047
**Right to work:** UK citizen (no sponsorship required)

## Professional Summary

First Class BSc Cyber Security graduate with a strong grounding in networking, server management and virtualisation, and security best practice. Currently providing first-line technical support on Chromebooks, building on four years of customer-facing technical advice in consumer electronics retail. Clear communicator who explains technical issues in plain language, works methodically through problems, and is keen to start a full-time career in IT support or IT operations.

## Work Experience

### West Walsall E-ACT Academy -- West Midlands, UK

**Duty Officer**
February 2026 - Present

- Incident response and crisis management: Primary on-site responder for urgent incidents, staying calm and using structured problem-solving to resolve site issues and keep services running
- Operational compliance: Maintain a 100% safety and protocol compliance record, applying the same rigour to health and safety and site procedures that IT work demands for data protection and service levels
- Cross-department communication: Coordinate between internal staff, management and external technical contractors, turning operational needs into practical workflows

### Gekko -- West Midlands, UK

**Brand Ambassador (Chromebook Focus)**
April 2025 - Present

- Provide first-line technical support for Chromebook setup and operating system troubleshooting, acting as the first point of contact for technical queries
- Act as product subject matter expert, turning detailed technical knowledge into clear, accessible guidance for colleagues and customers
- Help customers choose devices that fit their needs, and resolve questions on the spot

### Currys -- West Midlands, UK

**Sales Adviser**
November 2021 - April 2025

- Gave technical advice on a wide range of devices, translating technical jargon into clear, practical recommendations
- Handled cash transactions and stock management accurately, showing the attention to detail needed for data entry and administrative work
- Delivered consistently strong customer service in a fast-paced, target-driven environment

## Projects

- **Secure mesh network (Final year project)** -- Designed and built a secure mesh network using Raspberry Pis with VPN encryption, developing practical network deployment and security skills
- **Enterprise environment simulation** -- Deployed, managed and secured devices within a simulated corporate network, building proactive troubleshooting skills
- **Ethical hacking labs** -- Carried out penetration testing and vulnerability assessments, sharpening the ability to isolate the root cause of system faults

## Education

- **BSc (Hons) Cyber Security, First Class Honours** -- University of Wolverhampton, 2018 - 2021. Key modules: Server Management and Virtualisation, Advanced Computer Networking, Ethical Hacking and Vulnerability Assessment
- **BTEC Extended Diploma in Computer Networks (Level 3)** -- Walsall College, 2016 - 2018

## Technical Skills

- **Support and troubleshooting:** First-line fault diagnosis, device setup and configuration, ChromeOS and general operating system troubleshooting, hardware and software issue resolution
- **Networking:** Network design and deployment, VPN encryption, mesh networking, advanced computer networking concepts
- **Systems:** Server management, virtualisation, simulated enterprise environments
- **Security:** Ethical hacking, penetration testing, vulnerability assessment, security fundamentals
- **Soft skills:** Customer service, technical communication, knowledge sharing, attention to detail, working under pressure

## Interests

Cyber security trends and ethical hacking, reading technical books and following educational tech content, fitness and team sports, collaborative learning
