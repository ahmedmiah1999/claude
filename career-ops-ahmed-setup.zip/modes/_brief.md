# Ahmed Miah — Triage Brief

## Identity
Entry-level / graduate IT support and cyber security. First Class BSc (Hons) Cyber Security
(2021). Walsall, West Midlands (Europe/London). UK citizen, no sponsorship. No clearance held.
Current: first-line Chromebook support (Gekko), Duty Officer (E-ACT academy). Prior: 4 yrs
technical retail advice (Currys).

## Target Archetypes
A direct hit scores 4–5; an adjacent title scores 3; a mismatch scores 1–2.

| # | Archetype | What they buy (your proof) |
|---|-----------|----------------------------|
| 1 | **IT Support / Service Desk Analyst (1st–2nd line)** | Live first-line support, ChromeOS/OS troubleshooting, years of plain-language customer communication |
| 2 | **SOC / Cyber Security Analyst (Tier 1, graduate)** | First Class cyber degree, ethical hacking and vulnerability assessment labs, calm incident handling |
| 3 | **Infrastructure / Network Support (entry)** | Server management, virtualisation, networking modules, BTEC L3 networks, secure VPN mesh network project |
| 4 | **Graduate scheme (IT / Cyber)** | Strong academic record plus real workplace experience |

Analogs (score as targets): IT Technician, Desktop Support, Technical Support Analyst,
Junior Sysadmin, Junior Network Engineer, Security Operations Analyst, Vulnerability Analyst,
IT Analyst in education / NHS / public sector.

## Proof Points (use exact wording from cv.md)
- First Class BSc (Hons) Cyber Security, University of Wolverhampton
- Built a secure mesh network on Raspberry Pis with VPN encryption (final year project)
- Ethical hacking labs: penetration testing and vulnerability assessments
- First-line technical support for Chromebook setup and OS troubleshooting (Gekko)
- 100% safety and protocol compliance record; primary on-site incident responder (E-ACT)
- Four years of customer-facing technical advice (Currys)

## Comp Strategy
| Target | Requirement |
|--------|-------------|
| £30k+  | Any on-target role, West Midlands or UK remote |
| £27k–£29.9k | MARGINAL only if strong training/certs or clear progression is stated |

**Hard floor: £30,000. Clearly below £27k → FAIL. Unstated salary → do not penalise.**

## Location Scoring
- Fully remote (UK) → **5.0**
- Hybrid / on-site in West Midlands commutable area → **4.5–5.0**
- Hybrid elsewhere, light office days → **4.0**
- On-site requiring relocation → **2.0**
- Outside the UK → **FAIL**

## Hard DQ Criteria — instant FAIL (< 3.0)
- Senior / lead / manager / architect level, or 3+ years of professional SOC, sysadmin or network engineering explicitly required
- Active SC or DV clearance required on day one (willing/eligible to obtain is fine)
- Primary role is software development, sales, or a non-IT discipline
- Role based outside the UK or requiring non-UK work authorisation
- Stated salary ceiling below £27k

## Quick Scoring Guide

| Score | Verdict | What it means |
|-------|---------|---------------|
| ≥ threshold (default 3.5) | **PASS** | Clears the bar — strong archetype + comp + location, gaps bridgeable |
| 3.0 – (threshold − 0.1) | **MARGINAL** | Borderline — shown to user as one line |
| < 3.0 | **FAIL** | Does not clear the bar — filtered |

## Soft Red Flags (−0.5 each, additive)
- Certification listed as essential that the candidate lacks (e.g. CompTIA Security+, CCNA, Microsoft AZ-900/MD-102, CySA+)
- Heavy specific tooling as essential with no training offered (e.g. Splunk/Sentinel admin, Intune/SCCM at 2nd/3rd line depth)
- Driving licence / own vehicle required for multi-site field work (candidate status unconfirmed)
- Recruitment-agency listing with the employer hidden

## Priority Override List — always return PASS regardless of score
- (none yet)
